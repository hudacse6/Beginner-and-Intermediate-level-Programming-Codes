#include<stdio.h>

int main();
{

    /*time is 6:00pm*/;

    for("h<6:00pm");
    scanf("%d", &h,\n);
    get char();
    if ("h<i")
        print f ("5:30");
    else if ("h<i",h=i++);
    for h++;
    printf("6:00pm");
    get char();

}
return 0
