#include<bits/stdc++.h>
using namespace std;
int main()
{
    /// Ceaser Cipher Encryption/Decryption Code
    char  pt[101];
    char ct[101];
    int key;
    cout<<"Enter input Plain Text:"<<endl;
    scanf(" %[^\n]",pt);
    int len=strlen(pt);
    cout<<"Enter input Key:"<<endl;
    cin>>key;
    for(int i= 0 ; i<len ; i++)
    {
        if(pt[i]>='A' && pt[i]<='Z')
        {
            int temp = pt[i]+key;
            if(temp>'Z')
            {
                ct[i] = 64 + (temp-'Z');
            }
            else
                ct[i] = temp;
        }

        else
        {
            int temp = pt[i]+key;
            if(temp>'z')
            {
                ct[i] = 96 + (temp-'z');
            }
            else
                ct[i] = temp;
        }
    }
    cout<<"Encrypted Message is: "<<ct<<endl;

    cout<<"this is a decryption part of ceaser cipher:"<<endl<<endl;

    for(int i= 0 ; i<len ; i++)
    {
        if(ct[i]>='A' && ct[i]<='Z')
        {
            int temp = ct[i]-key;
            if(temp<'A')
            {
                pt[i] = 91 - ('A'-temp);
            }
            else
                pt[i] = temp;
        }

        else
        {
            int temp = ct[i]-key;
            if(temp<'a')
            {
                pt[i] = 123 - ('a'-temp);
            }
            else
                pt[i] = temp;
        }
    }
    cout<<"Decrypted Message is: "<<pt<<endl;
}
