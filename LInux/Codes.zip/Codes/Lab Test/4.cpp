#include<bits/stdc++.h>
using namespace std;

int main()
{
    char pt[101];
    int key,len,row,filler=0;

    cout<<"Input Plain Text:";
    gets(pt);
    len = strlen(pt);

    cout<<"Input Key: ";
    cin>>key;

    int com[key];
    cout<<"Input Column Combination ";
    for(int i=0; i<key; i++)
        cin>>com[i];

    if(len%key==0)
    {
        row = len / key;
    }

    else
    {
        filler = key - (len%key);
        row = (len / key)+1;
        char fil='@';
        int r=0;
        for(int i= len; i<(len+filler); i++)
        {
            pt[i]=fil;
            r++;
        }
        len += filler;
    }

    char mat[row][key];
    int k=0;
    int q=0;
    cout<<"Transposition Matrix:"<<endl;
    for(int i=0; i<row; i++)
    {
        for(int j=0; j<key, k<len; j++)
        {
            mat[i][j]=pt[k];
            cout<<"\t"<<mat[i][j];
            k++;
            q++;
            if(q%key==0)
            {
                cout<<"\n";
            }
        }
    }

    cout<<"\n\n";
    char mat2[row][key];
    int l;
    int q2=0;
    for(int m=0; m<row; m++)
    {
        for(int n=0; n<key; n++)
        {
            l = com[n];
            mat2[m][l] = mat[m][n];
        }
    }

    cout<<"Cipher Text: ";
    for(int i=0; i<key; i++)
        for(int j=0; j<row; j++)
            cout<<mat2[j][i];

    cout<<"\n\n";
    for(int i=0; i<row; i++)
    {
        for(int j=0; j<key; j++)
        {
            cout<<"\t"<<mat2[i][j];
            q2++;
            if(q2%key==0)
            {
                cout<<"\n";
            }
        }
    }

    char mat3[row][key];
    int l2;
    for(int m=0; m<row; m++)
    {
        for(int n=0; n<key; n++)
        {
            l2 = com[n];
            mat3[m][l2] = mat2[m][n];
        }
    }

    cout<<"New Cipher Text: ";
    for(int i=0; i<key; i++)
        for(int j=0; j<row; j++)
            cout<<mat3[j][i];


    return 0;
}
