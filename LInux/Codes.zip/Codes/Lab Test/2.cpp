#include<bits/stdc++.h>
using namespace std;

int main ()
{
    int len,j=0;
    char src[100],ch;


    cout << "Enter a text to encrypt: " << endl;
    cin >> src;
    cout<<"result: "<<endl;
    len = strlen (src);

    while(j<=25)
    {
        for (int i=0; i < len; i++)
        {
            ch=src[i];
            if (ch>='A'&& ch<='Z')
            {
                ch=(((ch-1-'A'+26)%26)+'A');
            }
            else if (ch >='a'&& ch<='z')
            {
                ch=(((ch-1-'a'+26)%26)+'a');
            }
            src[i]=ch;
        }
        j++;
        cout<<src<<endl;
    }
}
