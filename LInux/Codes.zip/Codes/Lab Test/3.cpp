#include<bits/stdc++.h>
using namespace std;

int main()
{
    char pt[101];
    char ct[101];
    char decr[101];
    char ind;
    int key,len,row;

    cout<<"Input Plain Text:";
    gets(pt);
    len = strlen(pt);

    cout<<"Input Key: ";
    cin>>key;

    if(len%key==0)
    {
        row = len / key;
    }

    char mat[row][key];
    int k=0;

    for(int i=0; i<row; i++)
    {
        for(int j=0; j<key, k<len; j++)
        {
            mat[i][j]=pt[k];
            k++;
        }
    }

    int p=0;
    cout<<endl;
    cout<<"Cypher Text: ";
    for(int m=0; m<key; m++)
    {
        for(int n=0; n<row; n++)
        {
            ct[p]=mat[n][m];
            p++;
        }
    }

    cout<<"Cypher Text:  "<<ct;

    return 0;
}
