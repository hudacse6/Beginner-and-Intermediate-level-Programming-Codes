#include<bits/stdc++.h>
using namespace std;
string generateKey(string str, string key)
{
    int x = str.size();
    for (int i = 0; ; i++)
    {
        if (x == i)
            i = 0;
        if (key.size() == str.size())
            break;
        key.push_back(key[i]);
    }
    return key;
}
string cipherText(string str, string key)
{
    string cipher_text;
    for (int i = 0; i < str.size(); i++)
    {
        int x = (str[i] + key[i]) %26; /// converting in range 0-25
        x += 'A';/// convert into alphabets(ASCII)
        cipher_text.push_back(x);
    }
    return cipher_text;
}
string originalText(string cipher_text, string key)
{
    string orig_text;
    for (int i = 0 ; i < cipher_text.size(); i++)
    {
        int x = (cipher_text[i] - key[i] + 26) %26;  /// converting in range 0-25
        x =x + 'A';/// convert into alphabets(ASCII)
        orig_text.push_back(x);
    }
    return orig_text;
}
int main()
{
    char str[1001];
    char keyword[1001];
    cout<<"Enter Cipher Text:"<<endl;
    scanf(" %[^\n]",str);
    cout<<"Enter KeyWord :";
    scanf(" %[^\n]",keyword);
    string key = generateKey(str, keyword);
    string cipher_text = cipherText(str, key);
    cout << "Cipher Text/Encrypted Text : "<< cipher_text << "\n";
    cout << "Original/Decrypted Text : "<< originalText(cipher_text, key);

    return 0;
}


//#include<bits/stdc++.h>
//using namespace std;
//int main()
//{
//    char pt[101],key1[15];
//    cout<<"Enter all in Capital letter: \n";
//    printf("Enter PlainText(Capital Letter Only):");
//    gets(pt);
//    printf("Enter key(Capital Letter Only):");
//    gets(key1);
//
//    int klen,plen,x,y;
//    klen = strlen(key1);
//    plen = strlen(pt);
//
//    char ct[plen],key2[plen],pt2[plen];
//    x = plen/klen;
//    y = plen%klen;
//    int k = 0;
//    for(int i=0; i<plen; i++)
//    {
//        if(pt[i]==' ')
//        {
//            key2[i] = ' ';
//        }
//        else
//        {
//            key2[i] = key1[k];
//            k++;
//            if(k == klen)
//            {
//                k = 0;
//            }
//        }
//    }
//    cout<<"Encrypted Cipher Text is: ";
//    for(int i=0; i<plen; i++)
//    {
//        if(pt[i]>=65 && pt[i]<=90)
//        {
//            ct[i] = (pt[i]+key2[i])%26;
//            ct[i] = ct[i] + 'A';
//        }
//        else
//        {
//            ct[i]=pt[i];
//        }
//
//    }
//    cout<<ct<<endl;
//
//    cout<<"Decrypted Plain Text is: ";
//    for(int i=0; i<strlen(ct); i++)
//    {
//        if(pt[i]>=65 && pt[i]<=90)
//        {
//            pt2[i] = (ct[i]-key2[i]+26)%26;
//            pt2[i] = pt2[i] + 'A';
//        }
//        else
//        {
//            pt2[i]=ct[i];
//        }
//
//    }
//    cout<<pt2<<endl;
//}
