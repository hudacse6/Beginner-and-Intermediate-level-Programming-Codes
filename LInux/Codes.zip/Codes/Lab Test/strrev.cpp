#include<bits/stdc++.h>
#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    char str[100]="Hadisur Rahman";
    strrev(str);
    cout<<str;
}
