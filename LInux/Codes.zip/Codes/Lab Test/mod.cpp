#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n1, n2 , n3;
    int tcase;
    while(tcase--)
    {
        cout<< "Enter Number: "<<endl;
        cin>> n1 ;

    }
}
