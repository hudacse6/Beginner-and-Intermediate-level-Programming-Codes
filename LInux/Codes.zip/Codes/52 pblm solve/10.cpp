#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
        double r1,r2,b,currate,exrate;
        int playedBall;
        int tcase;
        cin>>tcase;
        while(tcase--)
        {
            cin>>r1>>r2>>b;
            playedBall=300-b;
            currate=(r2/playedBall)*6;
            exrate=((r1-r2+1)/b)*6;
            printf("%.2lf %.2lf\n",currate,exrate);
        }
        return 0;
}
