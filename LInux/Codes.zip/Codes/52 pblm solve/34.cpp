#include<iostream>
#include<stdio.h>
#include <cstdio>
#include<math.h>
using namespace std;
int main()
{
    freopen("34.txt","r",stdin);
    int tcase;
    long int a,b,c,i,sum,lcm;
    cin>>tcase;
    while(tcase--)
    {
        cin>>a>>b>>c;
//        sum=a*b;
//        int temp;
//        while( b != 0 )
//        {
//            temp= b;
//            b=a%b;
//            a=temp;
//        }
//        lcm=sum/a;

        for(i = a ; i<= c ; i++)
        {
            if( i%a==0 && i%b==0)
            {
                cout<<i<<endl;
            }
        }
        cout<<endl;
    }
    return 0;
}
