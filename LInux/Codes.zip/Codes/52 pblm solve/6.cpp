//#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int n,cont;
    int T;
    cin>>T;
    while(T--)
    {
        cin>>n;
        printf("Sum = %d",(n/10000+n%10) );
        cout<<endl;
    }
    return 0;
}
