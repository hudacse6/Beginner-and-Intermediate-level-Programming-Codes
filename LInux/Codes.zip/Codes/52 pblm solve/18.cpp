//#include<bits/stdc++.h>

#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    int tcase,i,j;
    char S[1001],S2[1001],s3[1001];
    cin>> tcase;
    while(tcase--)
    {
        int cont;
        scanf(" %[^\n]",S);
        int len=strlen(S);
        for( i= 0 ; S[i] != '\0'; i++)
        {
            if(S[i]=='a' || S[i]=='e' || S[i]=='i' || S[i]=='o' || S[i]=='u' )
                cout<<S[i];
        }

        printf("\n");

        for( i= 0 ; S[i] != '\0'; i++)
        {
            if( S[i] != 'a' && S[i] != 'e' && S[i] != 'i' && S[i] != 'o' && S[i] != 'u' && S[i] != ' ')
                cout<<S[i];
        }
        cout<<endl;
    }

    return 0;
}

