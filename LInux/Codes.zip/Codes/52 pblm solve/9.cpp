#include<bits/stdc++.h>
#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    double k;
    double n,T;
    cin>>T;
    while(T--)
    {
        cin>>n;
        k=sqrt(n);
        if(ceil(k)==floor(k))
        {
            cout<<"YES"<<endl;
        }
        else
        {
            cout<<"NO"<<endl;
        }
    }
    return 0;
}
