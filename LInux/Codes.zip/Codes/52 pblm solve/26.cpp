/// LCM

#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int tcase,cont;
    double X;
    cin>>tcase;
    while ( tcase--)
    {
        cin>>X;
        cont;
        while(X >=1.0)
        {
            X=X/2;
            cont++;
        }
        cout<<cont<<" days"<<endl;
        cont=0;
    }
    return 0 ;
}

