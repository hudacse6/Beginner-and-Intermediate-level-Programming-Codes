//#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int tcase;
    int a,b,i;
    cin>>tcase;
    while(tcase--)
    {
        cin>>a>>b;
        int temp=a;
        if( a>b)
        {
            cout<<"Invalid!"<<endl;
        }
        else
        {
            for(i= a ; i<=b ; i+=a)
            {

                if( a <= b )
                {
                    cout<<i<<endl;
                }
            }
        }
        a=0;

    }
    return 0;
}
