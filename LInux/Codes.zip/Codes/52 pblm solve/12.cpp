#include<bits/stdc++.h>
#include<iostream>
using namespace std;
//#include<stdio.h>
int main()
{

    int t;
    int a[200]; //array will have the capacity to store 200 digits.
    int n,i,j,temp,m,x;
    scanf("%d",&t);
    while(t--)
    {
        int cont=0;
        scanf("%d",&n);
        a[0]=1;  //initializes array with only 1 digit, the digit 1.
        m=1;    // initializes digit counter
        temp = 0; //Initializes carry variable to 0.
        for(i=1; i<=n; i++)
        {
            for(j=0; j<m; j++)
            {
                x = a[j]*i+temp; //x contains the digit by digit product
                a[j]=x%10; //Contains the digit to store in position j
                temp = x/10; //Contains the carry value that will be stored on later indexes
            }
            while(temp>0) //while loop that will store the carry value on array.
            {
                a[m]=temp%10;
                temp = temp/10;
                m++; // increments digit counter
            }
        }
        for(i=0; i<=m-1; i++) //printing answer
        {
            // printf("%d\n",a[i]);
            if(a[i]==0)
            {
                cont++;
            }
            else
            {
                if(a[i]!=0)
                    break;
            }
        }
        cout<<cont<<endl;
    }
    return 0;
}

//#include<bits/stdc++.h>
//using namespace std;
//int main()
//{
//
//    int n,j,temp;
//    int arr[200];
//    arr[0]=1;
//    j=0;//for index of array arr
//    cout<<"Enter the number.:";
//    cin>>n;
//    for(; n>=2; n--)
//    {
//        temp=0;
//        for(int i=0; i<=j; i++)
//        {
//            temp=(arr[i]*n)+temp;
//            arr[i]=temp%10;
//            temp=temp/10;
//        }
//
//        while(temp>0)//for
//        {
//            arr[++j]=temp%10;
//            temp=temp/10;
//        }
//    }
//
//    for(int i=j; i>=0; i--)
//        printf("%d",arr[i]);
//    return 0;
//
//}


//#include<bits/stdc++.h>
////#include<iostream>
//using namespace std;
//int main()
//{
//    char a[1001];
//    int fact,n;
//    int tcase;
//    cin>>tcase;
//    while(tcase--)
//    {
//        cin>>a;
//        int len=strlen(a);
//        n=sizeof(a)/sizeof(a[0]);
//        cout<<n;
//        for(int i= 0 ; i<len ; i++)
//        {
//            a[i]=(int)49;
//        }
//        for(int j= 0 ; j<len ; j++)
//        {
//            cout<<a[j];
//        }
//
////        int k=1;
////
////        for(int j=1 ; j<=fact ; j++)
////        {
////            a[k]=a[k]*j;
////            cout<<a[k]<<" ";
////        }
////        cout<<endl;
//
//
//    }
//
//    return 0;
//}
