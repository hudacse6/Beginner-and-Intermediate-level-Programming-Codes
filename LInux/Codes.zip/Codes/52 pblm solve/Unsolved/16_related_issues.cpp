#include<bits/stdc++.h>
//#include<iostream>
//#include<stdio.h>
//#include<string>
//#include<string.h>
using namespace std;
int main()
{
    char s1[1002];
    scanf(" %[^\n]", s1);
    int len=strlen(s1);
    cout<<len;

}

