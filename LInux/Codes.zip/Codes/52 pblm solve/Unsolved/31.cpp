//#include<bits/stdc++.h>
#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    unsigned long int T,i,N,num,sqrtNum,sum;
    cin>>T;
    while(T--)
    {
        cin>>N;
        for( num= 0 ; num <=N; num++)
        {
            sum=1;
            sqrtNum=sqrt(num);
            for(i=2; i<=sqrtNum; i++)
            {
                if(num%i==0)
                {
                    sum=sum+i+num/i;
                }
            }
            if(sum==num)
            {
                cout<<num<<endl;
            }
        }
        cout<<endl;
    }
    return 0;
}
