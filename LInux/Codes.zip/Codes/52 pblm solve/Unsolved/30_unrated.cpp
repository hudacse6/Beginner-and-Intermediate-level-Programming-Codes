//#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()

{
    int tcase;
    unsigned long long ar[8]= {6,28,496,8128,33550336,8589869056,137438691328,2305843008139952128},n,i ,len;
    cin>>tcase;
    while(tcase --)
    {
        int cont=0;
        scanf("%llu",n);
         len=sizeof(ar)/sizeof(ar[0]);
        for(i = 0 ; i < len ; i++)
        {

            if( ar[i] == n)
            {
                cout<<"YES, "<<n<<" is a perfect number!"<<endl;
                cont++;
            }
        }
        for(i = 0 ; i<=len ; i++ )
        {
            if( (cont<1) && (ar[i] != n) )
            {
                cout<<"NO, "<<n<<" is not a perfect number!"<<endl;
                break;
            }

        }
        i=0;
        cout<<endl;
    }
   // cout<<endl;
    return 0;
}

