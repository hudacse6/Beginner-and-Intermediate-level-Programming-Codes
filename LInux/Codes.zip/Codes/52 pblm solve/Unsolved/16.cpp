#include<bits/stdc++.h>
using namespace std;


void print_reverse(char str[])
{
    for(int i=strlen(str) ; i>=0 ; i--)
    {
        cout<<str[i];
    }
}

int main()
{
    char S[1002];
    char word[1002];
    int tcase,j,k,i;
    cin >> tcase;
    while(tcase--)
    {
        scanf(" %[^\n]", S);
        int len=strlen(S),len2;
        for(j= 0,k=0; j<len ; j++)
        {
            len2=0;
            if(S[k]!=' ')
            {
                word[k]=S[j];
                k++;
            }
            else if( k>0 )
            {
                word[k]='\0';
                print_reverse(word);
                cout<<" ";
                k=0;
            }
        }
        if(k>0)
        {
            word[k]='\0';
            print_reverse(word);
        }
        cout<<endl;
    }
    return 0;
}

