//#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int cont;
    for(int i=1000 ; i >= 1 ; i--)
    {
        cout<<i<<"\t";
        cont++;
        if(cont%5==0)
        {
            cout<<"\n";
        }
    }
    return 0;
}
