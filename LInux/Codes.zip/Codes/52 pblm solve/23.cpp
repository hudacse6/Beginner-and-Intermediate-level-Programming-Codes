#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    int tcase ;
    char str[1001];
    cin>> tcase;
    while(tcase--)
    {
        int cont;
        scanf(" %[^\n]",str);
        int len=strlen(str);
        for(int i= 0 ; i<len ; i++)
        {
            str[i]=str[i]-'A';
            cout<<str[i]+1;
           // cout<<(int)str[i]+1;
        }
        cout<<endl;
    }
    return 0;
}







