#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    char s1[1001], s2[1001];
    int tcase,temp,i,j;
    cin>>tcase;

    while(tcase--)
    {
        cin>>s1>>s2;
        strrev(s2);
        temp=strcmp(s1,s2);
        if(temp==0)
        {
            cout<<"Yes! It is a palindrome!"<<endl;
        }
        else {
            cout<<"Sorry! It is not a palindrome!"<<endl;
        }


    }
    return 0;
}


