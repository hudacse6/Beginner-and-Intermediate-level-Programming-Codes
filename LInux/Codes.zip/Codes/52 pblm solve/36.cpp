#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    char s[10001];
    int tcase;
    int n,i,j,temp,k;
    cin>>tcase;
    while(tcase--)
    {
        cin>>n;
        for(i= 0 ; i <n ; i++)
        {
            cin>>s[i];
        }

        for(i= 0 ; i<n ; i++)
        {
            for(j = i ; j< n ; j++)
            {
                if(strcmp(s[i],s[j]) > 0)
                {
                    strcpy(temp,s[i]);
                    strcpy(s[i],s[j]);
                    strcpy(s[j],temp);
                }
            }
            cout<<" "<<s<<" "<<endl;
        }
    }
    return 0;
}
