/// LCM

#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int a,b,c,LCM;
    int tcase;
    cin>>tcase;
    while ( tcase--)
    {
        cin>>a>>b;
        int temp;
        c=a*b;
        while( b != 0  )
        {
            temp = b;
            b = a%b;
            a= temp;
        }
        LCM= c/a;
        cout<<"LCM = " << LCM <<endl;
    }
    return 0 ;
}
