#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int fact;
    int tcase;
    cin>>tcase;
    while(tcase--)
    {
        cin>>fact;
        long long int n=1;

        for(int i=2 ; i<=fact ; i++)
        {
            n=n*i;
            cout<<n<<endl;
        }

    }
    return 0;
}
