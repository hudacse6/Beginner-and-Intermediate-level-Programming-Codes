#include<iostream>
using namespace std;
int main()
{
    int tcase,n;
    int temp;
    cin>>tcase;

    while(tcase--)
    {
        cin>>n;
        while(n!=0)
        {
            temp=n%10;
            n=n/10;
            cout<<temp;
        }
        cout<<endl;
    }
    return 0;
}
