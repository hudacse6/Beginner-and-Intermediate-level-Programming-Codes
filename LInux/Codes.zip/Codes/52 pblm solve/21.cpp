//#include<bits/stdc++.h>

#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    int tcase ;
    char S[1001];
    cin>> tcase;
    while(tcase--)
    {
        int cont;
        scanf(" %[^\n]",S);
        int len=strlen(S);
        for(int i= len-1 ; i>=0 ; i--)
        {
           cout<<S[i];
        }
        cout<<endl;
    }
    return 0;
}
