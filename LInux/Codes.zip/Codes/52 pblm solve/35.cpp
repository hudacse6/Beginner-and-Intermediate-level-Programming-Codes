#include<bits/stdc++.h>
#include<iostream>
#include<math.h>
using namespace std;
int main()
{

    int tcase;
    double x1,y1,x2,y2,r,temp;
    cin>>tcase;
    while(tcase--)
    {
        cin>>x1>>y1>>r>>x2>>y2;
        temp=sqrt( pow(x2-x1,2) + pow(y2-y1,2));
        if(temp<=r)
        {
            cout<<"The point is inside the circle"<<endl;
        }
        else
        {
            cout<<"The point is not inside the circle"<<endl;
        }
    }
    return 0;
}
