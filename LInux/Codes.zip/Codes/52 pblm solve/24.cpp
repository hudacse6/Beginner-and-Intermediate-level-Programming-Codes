#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    int tcase,i,n;
    int ar[1001];
    int p=1;
    cin>> tcase;
    while(tcase--)
    {
        cin>>n;
        for(i= 0 ; i<n; i++ )
        {
            cin>>ar[i];
        }
        cout<<"Set "<<p<<": ";
        for( i= 0 ; i<n ; i+=2)
        {
            cout<<ar[i]<<" ";
        }
        cout<<endl;
        p++;
    }
    return 0;
}

