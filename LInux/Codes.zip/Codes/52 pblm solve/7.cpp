//#include<bits/stdc++.h>
#include<iostream>
#include<string>
#include<string.h>
#include<math.h>
using namespace std;
int main()
{
    char str[1000001];
    int n,cont=0;
    int T;
    cin>>T;
    while(T--)
    {
        scanf(" %[^\n]",str);
        n=strlen(str);
        for( int i = 0 ; i<=n ; i++)
        {
            if(str[i]==' ')
            {
                cont++;
            }

        }
        cout<<cont+1<<endl;
        cont=0;
    }
    return 0;
}

