//#include<bits/stdc++.h>
#include<iostream>
#include<algorithm>
//#include<string>
//#include<string.h>
//#include<math.h>
using namespace std;
int main()
{
    int n[1000];
    int a,b,c;
    int T;
    int cases=1;
    cin>>T;
    while(T--)
    {
        for(int p= 0 ; p<3 ;p++)
        {
            cin>>n[p];
        }

        for(int i = 0 ; i <3 ; i++)
        {
            for(int j= i+1 ; j< 3 ; j++)
            {
                if( n[i] > n[j])
                    swap (n[i] , n[j]);
            }
        }

        for(int k = 0 ; k<3 ; k++)
        {
            cout<<n[k]<<" ";
        }
        cout<<endl;

    }
    return 0;
}
