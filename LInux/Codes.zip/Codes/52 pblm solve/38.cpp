#include<iostream>
using namespace std;
int main()
{
    int tcase,n,m,i,j;
    cin>>tcase;

    while(tcase--)
    {
        cin>>n>>m;
        for(i = 1 ; i<=n ; i++)
        {
            for(j= 1 ; j<=i ; j++)
            {
                cout<<m;
            }
            cout<<endl;
        }


        for(i = n-1 ; i>=1 ; i--)
        {
            for(j= i ; j>=1 ; j--)
            {
                cout<<m;
            }
            cout<<endl;
        }

    }
    return 0;
}

