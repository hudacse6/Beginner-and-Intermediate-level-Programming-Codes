#include<bits/stdc++.h>
using namespace std;
int main()
{
    int tcase,i,j;
    char s1[1001];

    cin>>tcase;
    while(tcase--)
    {
        int cont=1;
        scanf(" %[^\n]",s1);
        int len=strlen(s1);
        sort(s1,s1+len);
        // cout<<s1;
        for( i = 0 ; i <len ; i++)
        {
            if(s1[i]==s1[i+1])
            {
                cont++;
            }
            else if( s1[i] != s1[i+1])
            {
                cout<<s1[i]<<" = "<<cont<<endl;
                cont = 1;
            }
        }
    }
    return 0;
}
