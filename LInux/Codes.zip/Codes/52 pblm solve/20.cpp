#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    int tcase;
    char S[10001] ;
    char *word;
    cin>>tcase;
    while(tcase--)
    {
        int cont;
        scanf(" %[^\n]",S);
        word = strtok (S,"?!.,; ");
        while (word != NULL)
        {
            if(strlen(word)>0)
                cont++;
            word = strtok (NULL,"?!.,; ");
        }
        cout<<"Count = "<<cont<<endl;
        cont=0;
    }

    return 0;
}

