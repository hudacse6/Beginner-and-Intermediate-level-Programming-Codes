#include<bits/stdc++.h>
#include<stdio.h>
//#include<conio.h>
using namespace std;

int main()
{
    int i,j,n;
    printf("Enter your number: ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        for(j=0;j<=i;j++)
        {
            goto lv:(10+j,10+i);
            printf("%d ",j);
        }
        for(j=0;j<=i;j++)
        {
            goto lv:(10-j,10+i);
            printf("%d ",j);
        }
        printf("\n");
    }
  return 0;
}
