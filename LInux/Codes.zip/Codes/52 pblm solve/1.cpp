#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int val,T;
    cin>>T;
    while(T--)
    {
        cin>>val;
        if(  val % 2==1)
        {
            cout<<"odd"<<endl;
        }
        else
        {
            cout<<"even"<<endl;
        }
    }
    return 0;
}
