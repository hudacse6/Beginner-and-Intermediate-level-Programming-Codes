#include<bits/stdc++.h>

#include<iostream>
using namespace std;
int main()
{
    int pNumber;
    int tcase;
    cin>>tcase;
    while(tcase--)
    {
        int cont=0;
        int sum=0;
        cin>>pNumber;
        for(int i=5 ; i<=pNumber ; i*=5)
        {
            cont=pNumber/i;
            sum=sum+cont;
        }
        cout<<sum<<endl;
    }
    return 0;
}
