/// LCM

//#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int tcase,cont,n,temp;
    cin>>tcase;
    while ( tcase--)
    {
        cin>>n;
        while( temp != 0 )
        {
            temp=n%10;
            cont++;
            temp=n/10;
        }
        cout<<cont;
        cont =0;
    }
    return 0 ;
}

