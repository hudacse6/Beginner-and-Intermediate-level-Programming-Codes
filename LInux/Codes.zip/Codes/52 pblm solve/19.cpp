#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    int tcase ;
    char S[10001];
    cin>> tcase;
    while(tcase--)
    {
        int cont;
        scanf(" %[^\n]",S);
        int len=strlen(S);
        for(int i= 0 ; i<len ; i++)
        {
            if(S[i]==' ' )
            {
                cont++;
            }
        }
        cout<<"Count = "<<cont+1<<endl;
        cont=0;
    }
    return 0;
}
