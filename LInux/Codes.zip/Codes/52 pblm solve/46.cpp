#include<iostream>
#include<stdio.h>
#include<math.h>
using namespace std;
int main()
{
    int tcase;
    double area;
    int i, j;
    int a,b,c,s;
    cin>>tcase;
    while( tcase--)
    {
        cin>>a>>b>>c;
        s=(a+b+c)/2;
        area=sqrt(s*(s-a)*(s-b)*(s-c));
        printf("Area = %.3lf\n",area);
    }
    return 0;
}
