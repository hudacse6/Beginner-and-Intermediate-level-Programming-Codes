#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int n;
    int cases=1;
    int T;
    cin>>T;
    while(T--)
    {
        cin>>n;
        printf("Case %d: ",cases);
        for( int i = 1 ; i<=n ; i++)
        {
            if(n % i ==0)
            {
                cout<<i<<" ";
            }
        }
         cout<<endl;
         cases++;

    }
     cases=0;
    return 0;
}
