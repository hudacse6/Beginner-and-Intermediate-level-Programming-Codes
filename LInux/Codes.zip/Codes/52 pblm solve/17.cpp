//#include<bits/stdc++.h>

#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    int tcase ;
    char S[1001];
    cin>> tcase;
    while(tcase--)
    {
        int cont;
        scanf(" %[^\n]",S);
        int len=strlen(S);
        for(int i= 0 ; i<len ; i++)
        {
            if(S[i]=='a' || S[i]=='e' || S[i]=='i' || S[i]=='o' || S[i]=='u'|| S[i]=='A' || S[i]=='E' || S[i]=='I' || S[i]=='O' || S[i]=='U' )
            {
                cont++;
            }
        }
        cout<<"Number of vowels = "<<cont<<endl;
        cont=0;
    }
    return 0;
}
