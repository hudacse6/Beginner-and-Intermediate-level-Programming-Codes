#include<iostream>
#include<math.h>
using namespace std;
int main()
{

}
