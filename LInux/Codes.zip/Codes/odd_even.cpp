#include<bits/stdc++.h>
using namespace std;
int main()
{
   //freopen("odd.txt", "r" , stdin);
    unsigned long long int  val;
    int t,n,m,p,cnt;
     p=1;
    t=100;
    while(t--)
   {
        cnt= 0;
        cin>>val;
        cout<<"Case ";
        for(int i = 2; i<sqrt(val)+1 ; i+=2)
        {
            if(((val/i)%2)!=0 && (val%i)==0)
            {
                m=i;
                n=val/i;
                cnt++;
            }

        }
        if(cnt!=0){
           printf( "%d: %d %d\n",p,n,m);
        }
        else{
            printf( "%d: Impossible\n",p);
        }

        p++;

    }
    return 0;
}
