#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    //bool flag;
    while(cin>>n)
    {
        int i,ar[n],cont=0;
        for(i= 0 ; i<n ;i++)
        {
            cin>>ar[i];

        }

        for(i= 0 ; i<n ;i++)
        {
            if((ar[i]-ar[i+1])==200 && ar[i] <= 1422 )
            {
                //a[i]+=200;
                cont++;
            }
            else if( (ar[i]-ar[i+1]) != 200 )
            {
                cout<<"Impossible"<<endl;
                break;
            }

        }
        if(cont!=0)
            cout<<"Possible"<<endl;

    }

    return 0;
}
