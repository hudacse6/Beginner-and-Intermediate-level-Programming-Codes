
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    //bool flag;
    while(cin>>n)
    {
        int i,j=0,ar[4]={0,23,45,12},cont=0;

            cont=ar[0]-ar[1];
         cout<<cont;

    }

    return 0;
}
