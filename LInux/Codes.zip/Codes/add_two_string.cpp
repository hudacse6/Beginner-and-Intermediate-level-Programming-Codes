#include<bits/stdc++.h>
using namespace std;
int main()
{
    char str[1001];
    char ch;
    int i;
    int len= strlen(gets(str));
    int word=0;
    for (i= 0 ; i<len ; i++)
    {
        if (word == 0 )
        {
            if(str[i] >='a' && str[i]<='z')
            {
                ch=str[i]-32;
                cout<<ch;
                word++;
            }
            else
            {
                ch=str[i];
                cout<<ch;
                if((str[i] >='a' && str[i]<='z') || (str[i] >='A' && str[i]<='Z'))
                    word=1;
            }
        }
        else
        {
            if(str[i] >='A' && str[i]<='Z' )
            {
                ch=str[i];
                cout<<ch;
            }
            else if(str[i] >='0' && str[i]<='9')
            {
                ch=str[i];
                cout<<ch;
            }
            else
            {
                ch=str[i];
                cout<<ch;
                if( str[i]==' ')
                {
                    word=0;
                }
            }
        }
    }
    return 0;
}

