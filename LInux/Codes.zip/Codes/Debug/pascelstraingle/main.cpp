/// coef=coef*(i-j+1)/2

#include<iostream>
using namespace std;
int main()
{
    int coef=1,n,sp;
    int i, j;
    int tcase;
    cin>>tcase;
    while(tcase--)
    {
        cin>>n;
        for(i= 0 ; i<n ; i++   )
        {
            for(sp= 1 ; sp<=n-i ; sp++   )
            {
                cout<<" ";
            }
            for(j = 0 ; j<i ; j++)
            {
                if( j==0 || i==0)
                {
                    coef=1;
                      //cout<<coef;
                }
                else
                {
                    coef=(coef*(i-j+1))/j;
                }
                cout<<coef<<" ";
            }
            cout<<endl;
        }
    }
    return 0;
}
