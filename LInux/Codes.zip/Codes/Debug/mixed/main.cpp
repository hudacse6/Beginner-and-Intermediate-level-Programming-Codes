#include<bits/stdc++.h>
using namespace std;
int main()
{
   int tcase,i;
   char s[1001];
   cin>>tcase;
   while(tcase--)
   {
       scanf(" %[^\n]", s);
       int len=strlen(s);
       for(i = len-1 ; i>=0 ; i--)
       {
            cout<<(s+i)<<endl;
       }
   }
   return 0;
}
