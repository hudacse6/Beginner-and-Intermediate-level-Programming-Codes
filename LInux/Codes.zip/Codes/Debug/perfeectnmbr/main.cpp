#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()

{
    int tcase,i,nn;
    //freopen("")
    unsigned long int n,sum=0;
    cin>>tcase;
    while(tcase --)
    {
        cin>>n;
        for(i = 1 ; i <=n ; i++)
        {
            nn=sqrt(i);
            for( int j = 2 ; j<= i ; j++ )
            {
                if( nn%i == 0)
                {
                    sum=sum+i;
                }
            }

        }
        if(sum==n)
        {
            cout<<"YES, "<<n<<" is a perfect number!"<<endl;
        }
        else
        {
            cout<<"NO, "<<n<<" is not a perfect number!"<<endl;
        }
        sum=0;
        //printf("\n");

    }
    return 0;
}
