#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    while(scanf("%d",&t) != EOF)
    {
        printf("%d\n",t/3);
    }
    return 0 ;
}
