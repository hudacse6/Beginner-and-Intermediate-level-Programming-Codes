#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,j,temp;
    int arr[200];
    arr[0]=1;
    j=0;//for index of array arr
    cout<<"Enter the number.:";
    cin>>n;
    for(; n>=2; n--)
    {
        temp=0;
        for(int i=0; i<=j; i++)
        {
            temp=(arr[i]*n)+temp;
            arr[i]=temp%10;
            temp=temp/10;
        }

        while(temp>0)//for
        {
            arr[++j]=temp%10;
            temp=temp/10;
        }
    }

    for(int i=j; i>=0; i--)
        printf("%d",arr[i]);
    return 0;

}


//#include<bits/stdc++.h>
////#include<iostream>
//using namespace std;
//int main()
//{
//    char a[1001];
//    int fact,n;
//    int tcase;
//    cin>>tcase;
//    while(tcase--)
//    {
//        cin>>a;
//        int len=strlen(a);
//        n=sizeof(a)/sizeof(a[0]);
//        cout<<n;
//        for(int i= 0 ; i<len ; i++)
//        {
//            a[i]=(int)49;
//        }
//        for(int j= 0 ; j<len ; j++)
//        {
//            cout<<a[j];
//        }
//
////        int k=1;
////
////        for(int j=1 ; j<=fact ; j++)
////        {
////            a[k]=a[k]*j;
////            cout<<a[k]<<" ";
////        }
////        cout<<endl;
//
//
//    }
//
//    return 0;
//}
