#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int fact,i;
    int tcase;
    cin>>tcase;
    while(tcase--)
    {
        cin>>fact;
        char n[1001];
        for( i=2 ; i<=fact ; i++)
        {
            n[i]=n[i]*i;
        }
        cout<<n[i]<<endl;
    }
    return 0;
}

