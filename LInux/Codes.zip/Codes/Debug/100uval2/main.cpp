#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n1,n2, i, j=0, val,mx,mn;
    while( scanf("%d %d",&n1,&n2)!=EOF)
    {
        int ar[10001],cont=0,mx;
        for(i = n1 ; i <= n2 ; i++)
        {
            ar[i]=0;
        }
        for(i = n1 ; i <= n2 ; i++)
        {
            val=i;
            if(val<=1)
            {
                cont++;
            }
            else
            {
                cont++;
                while(val>1)
                {
                    cont++;
                    if( val % 2 != 0)
                    {
                        val=3*val+1;
                    }
                    else
                    {
                        val=val/2;
                    }
                }
            }
            ar[i-1]=cont;
            cont=0;
        }
        int len=sizeof(ar)/sizeof(ar[0]);
        sort(ar,ar+len);
        for(i = 0 ; i<len ; i++)
        {
          cout<<ar[i]<<" ";
        }
        cout<<endl;
      //  cout<<n1<<" "<<n2<<" "<<mx<<endl;
    }
    return 0;
}
