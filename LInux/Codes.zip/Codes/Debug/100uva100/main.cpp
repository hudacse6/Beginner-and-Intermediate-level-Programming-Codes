#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n1,n2, i;
    bool flag;
    while( scanf("%d%d",&n1,&n2)!=EOF)
    {
        flag = false;
        if(n1>n2)
        {
            flag =true;
            swap(n1,n2);
        }
        int j=0, val;
        int ar[n2-n1+1];
        int cont=0;
        for(i = n1 ; i <= n2 ; i++)
        {

            val=i;
            if(val<=1)
            {
                cont++;
            }
            else
            {
                cont++;
                while(val>1)
                {
                    cont++;
                    if( val % 2 != 0)
                    {
                        val=3*val+1;
                    }
                    else
                    {
                        val=val/2;
                    }
                }
            }
            ar[j]=cont;
            cont=0;
            j++;
        }
        int len=sizeof(ar)/sizeof(ar[0]);
        int mx=ar[0];
        for(i = 0 ; i<len ; i++)
        {
            if(ar[i]>mx)
                mx=ar[i];
        }
        if(flag)
            swap(n1,n2);
        printf("%d %d %d\n",n1,n2,mx);
    }
    return 0;
}
