#include<bits/stdc++.h>
using namespace std;
int main()
{
    char str[1001];
    char ch;
    int i,j ;
    int len= strlen(gets(str));
    int word=0;
    for (i= 0 ; i<len ; i++)
    {
        if (word == 0 )
        {
            if( str[i] > 'a' && str[i]< 'z' )

            {
                ch=str[i]-32;
            }
            else
            {
                ch= str[i];

            }
        }
        cout<<ch;
        return 0;
    }
}
