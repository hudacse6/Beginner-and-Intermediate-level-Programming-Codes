#include<bits/stdc++.h>
using namespace std;
int main()
{

    char s1[100];
    char s2[100];
    int tcase,i,j;
    cin >> tcase;
    while(tcase--)
    {
        scanf(" %[^\n]", s1);
        int len=strlen(s1);
        for(i= 0; i<len ; i++)
        {
            if(s1[i]!=' ')
            {
                s2[i]=s1[i];

            }
            else if( true)
            {
                int len2=strlen(s2);
                for(j= len2 ; j>=0 ; j--)
                {
                     cout<<s2[j];
                }
               len2=0;
               j=len2;
            }

        }

    }
    return 0;
}

