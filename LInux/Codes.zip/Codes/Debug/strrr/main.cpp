//#include<bits/stdc++.h>
#include<iostream>
#include<string>
#include<string.h>
using namespace std;
int main()
{
    int tcase;
    char word,word2;
    char str[10001];
    cin>>tcase;
    while(tcase--)
    {
        int cont =0;
        scanf(" %[^\n]",str);
        scanf("%c",word);

        if(word>'a' && word<'z')
            word2=word-32;/// for make d char to upper-case
        else
            word2=word+32;

        int len=strlen(str);
        for(int i=0 ; i<len ; i++ )
        {
            if(str[i]==word || str[i]==word2)
            {
                cont++;
            }
        }
        if(cont !=0 )
        {
            printf("Occurrence of '%c' in '%s' = %d\n",word,str,cont);
        }
        else
        {
            printf("'%c' is not present\n",word);
        }
    }
    return 0;
}
