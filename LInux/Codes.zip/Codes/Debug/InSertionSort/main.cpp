#include <iostream>

using namespace std;

int main()
{
    int ar[10]= {8,1,2,4,7,6,1,5,3,2};
    int i,j;
    for(i= 0 ; i<10 ; i++)
    {
       j=i;
       while( (j>0) &&  (ar[j] < ar[j-1]) )
        {
             swap(ar[j], ar[j-1]);
             j-=1;
        }
    }

    for(i= 0 ; i<10 ; i++)
    {
        cout<<ar[i]<<" ";
    }

    return 0;
}
