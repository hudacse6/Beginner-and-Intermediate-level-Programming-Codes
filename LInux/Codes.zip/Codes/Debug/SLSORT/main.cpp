#include <iostream>

using namespace std;

int main()
{
    int ar[10]= {8,1,2,4,7,6,1,5,3,2};
    int i,j;
    int minn;
    for(i= 0 ; i<10 ; i++)
    {
        minn=i;
        for( j= i+1 ; j<10 ; j++)
        {
            if(ar[j]<ar[minn])
            {
                minn=j;
            }
        }
        swap(ar[minn], ar[i]);
    }
    for(i= 0 ; i<10 ; i++)
    {
        cout<<ar[i]<<" ";
    }

    return 0;
}
