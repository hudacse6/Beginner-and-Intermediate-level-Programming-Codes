//#include<bits/stdc++.h>
#include<iostream>
#include<string>
#include<string.h>
#include<math.h>
using namespace std;
int main()
{
    char str[1000001];
    int n,cont=0;
    int T;
    cin>>T;
    scanf(" %[^\n]",str);
    while(T--)
    {

        n=strlen(str);
        for( int i = 0 ; i<=n ; i++)
        {
            if(str[i]==' ')
            {
                cont++;
            }

        }
        cout<<cont;
    }

    return 0;
}

