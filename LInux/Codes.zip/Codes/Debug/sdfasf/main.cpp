#include<bits/stdc++.h>
//#include<iostream>
//#include<stdio.h>
//#include<string>
//#include<string.h>
using namespace std;
int main()
{
    char S[1002];
    char word[1002];
    int tcase,j,k,i;
    cin >> tcase;
    while(tcase--)
    {
        scanf(" %[^\n]", S);
        int len=strlen(S),len2;
        for(j= 0,k=0; j<len ; j++)
        {
            len2=0;
            if(S[k]!=' ')
            {
                word[k]=S[j];
                k++;
            }
            else if( k>0 )
            {
                word[k]='\0';
                len2=strlen(word);
                cout<<"length is "<<len2<<" ";
                for(i = len2-1 ; i>=0 ; i--)
                {
                    cout<<word[i];
                }
                cout<<" ";
                k=0;
                i=0;
                len2=0;
                word[k];
            }
        }
        if(k>0)
        {
            word[k]='\0';
            len2=strlen(word);
            for(i = len2-1 ; i>=0 ; i--)
            {
                cout<<word[i];
            }
            word[k];

        }
        cout<<endl;
    }
    return 0;
}

