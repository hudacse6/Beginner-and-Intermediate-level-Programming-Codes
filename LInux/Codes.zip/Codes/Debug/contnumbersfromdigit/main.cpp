/// LCM

//#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int tcase,cont=0,n,temp;
    cin>>tcase;
    while ( tcase--)
    {
        cin>>temp;
        while( temp != 0 )
        {
            temp/=10;
            cont++;
        }
        cout<<cont;
        cont =0;
    }
    return 0 ;
}

