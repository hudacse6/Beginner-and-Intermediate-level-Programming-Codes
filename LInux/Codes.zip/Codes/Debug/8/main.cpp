#include<bits/stdc++.h>
using namespace std;
int main()
{
    double k;
    int n,T;
    cin>>T;
    while(T--)
    {
        cin>>n;
        k=(int)sqrt(n);
        if(ceil(k)==floor(k))
        {
            cout<<"YES"<<endl;
        }
        else
        {
            cout<<"NO"<<endl;
        }
    }
    return 0;
}
