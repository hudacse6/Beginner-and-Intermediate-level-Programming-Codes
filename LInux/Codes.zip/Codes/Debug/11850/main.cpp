#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    bool flag;
    while(cin>>n)
    {
        if(n==0)
        {
            break;
        }
        flag = false;
        int i,j=0,ar[n],cont=0;
        for(i= 0 ; i<n ; i++)
        {
            cin>>ar[i];
        }
        int len=sizeof(ar)/sizeof(ar[0]);
        sort(ar,ar+len);
        for(i= 0 ; i<n ; i++)
        {

            if( (ar[i+1]-ar[i]) <= 200   )
            {
                cout<<"";
            }

            else if( (ar[i+1]-ar[i]) > 200  )
            {

                flag = true;
                cout<<"";
            }
            else if ((ar[len-1]+200) >= 1422  && (ar[len-1]+200) <= 1422 )
            {
                flag = true;
                cout<<"";
            }

        }
        if(flag)
            cout<<"IMPOSSIBLE"<<endl;
        else
            cout<<"POSSIBLE"<<endl;

    }
    return 0;
}


