#include <iostream>

using namespace std;

int main()
{
    int ar[10]= {8,1,25,4,7,6,1,5,46,2};
    int i,j;
    int minn;
    for(i= 0 ; i<10 ; i++)
    {
        minn=i;
        for( j= i+1 ; j<10 ; j++)
        {

            if(ar[j] < ar[minn])
            {
                minn=j;
            }
            swap(ar[i], ar[minn]);
        }
    }

    for(i= 0 ; i<10 ; i++)
    {
        cout<<ar[i]<<" ";
    }

    return 0;
}

