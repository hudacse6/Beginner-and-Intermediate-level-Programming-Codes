#include<bits/stdc++.h>
using namespace std;
int main()
{

   int n,i,j,k;
    char word[20],rev_word[20];
    cin>>k;
    int p=1;
    while(k--)
    {
        cin>>word;
        int len=strlen(word);
        for( i= 0,j=len-1 ; i<len ; i++, j--)
        {
            rev_word[i]=word[j];
        }
        rev_word[i]='\0';
        printf("Case %d: ",p);
        if(strcmp(word,rev_word)== 0)
        {
            cout<<"Yes"<<endl;
        }
        else
        {
            cout<<"No"<<endl;
        }
        p++;
    }
    return 0;
}
