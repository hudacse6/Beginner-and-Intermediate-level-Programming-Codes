#include<bits/stdc++.h>
using namespace std;
int main()
{
    int row,column,sum=0;
    cin>>row>>column;
    int a[row][column],b[row][column],c[row][column];
    cout<<"Enter 1st matrix:"<<endl;
    for(int i= 0 ; i<= row; i++)
    {
        for(int j= 0 ; j<= column ; j++)
        {
            cin>>a[i][j];
        }
    }
    cout<<"Enter 2nd matrix:"<<endl;
    for(int i= 0 ; i<= row; i++)
    {
        for(int j= 0 ; j<= column ; j++)
        {
            cin>>b[i][j];
        }
    }
    cout<<"Output :"<<endl;
     for(int i= 0 ; i<= row; i++)
    {
        for(int j= 0 ; j<= column ; j++)
        {
           sum=row[i][j]+column[i][j];
           cout<<sum <<" ";
        }
         cout<<endl;
    }

}
