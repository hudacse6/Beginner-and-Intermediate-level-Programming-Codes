#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n1,n2, i;
    while( scanf("%d %d",&n1,&n2)!=EOF)
    {
        if(n1>n2)
        {
           swap(n1,n2);
        }
        cout<<n1<<""<<n2;
    }


    return 0;
}
