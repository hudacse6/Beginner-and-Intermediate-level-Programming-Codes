#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,i,j,k;
    char word[100],rev_word[100];
    cin>>k;
    while(k--)
    {
        cin>>word;
        int len=strlen(word);

        for( i= 0,j=len-1 ; i<len ; i++, j--)
        {
            rev_word[i]=word[j];
        }
        rev_word[i]='\0';
        cout<<"Case :";
        if(strcmp(word,rev_word)== 0)
        {
            cout<<"Yes";
        }
        else
        {
            cout<<"No";
        }
    }
    return 0;
}