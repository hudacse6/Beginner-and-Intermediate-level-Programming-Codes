#include<bits/stdc++.h>
using namespace std;
int main()
{
    unsigned long int t;
    int temp;
    while( scanf("%lu",&t)  != EOF)
    {
        if( t%3==0)
            cout<<t/3<<endl;
        else
            cout<<t/3+1<<endl;
    }
    return 0 ;
}
