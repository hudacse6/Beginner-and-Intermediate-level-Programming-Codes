#include<bits/stdc++.h>
using namespace std;

int isprime(int a)
{
    if(a==0 || a==1) return 0;
    if(a==2) return 1;

    for(int i= 2 ; i<a/2 ; i+=2)
    {
        if( a %i==0)
        {
            return 0;
        }
    }
    return 1;
}

int main()
{
    int a,b,k;
    cin>>b;
    while(b--)
    {
        cin>>a;
        if(isprime(a)==1)
        {
            cout<<"This is a prime number"<<endl;
        }
        else
        {
            cout<<"This is NOT a prime number"<<endl;
        }
    }
}
